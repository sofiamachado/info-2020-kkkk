/* eslint-disable */
console.log('1 + 1 === 2', (1 + 1) === 2); // 1 + 1 === 2 true
