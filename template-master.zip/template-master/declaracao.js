let idade = 05;
console.log("idade = " + idade);
console.log("após um ano");
idade = 10;
console.log("idade = " + idade);
let it_go = "elsa";
const ano = 2020;
console.log("ano de nascimento " + ano);

