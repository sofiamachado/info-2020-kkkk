/* eslint-disable */
test('1 + 1 equal 2', () => {
  expect(1 + 1).toEqual(2);
});
