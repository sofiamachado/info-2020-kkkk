console.log("nasceu kkkk");
