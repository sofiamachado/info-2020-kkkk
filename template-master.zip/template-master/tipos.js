let itgo = "elsa";
console.log(itgo);
console.log(typeof(itgo));
itgo = 5;
console.log(itgo);
console.log(typeof(itgo));
let dados = {bim2:947249823743498236986, v: 0};
console.log(dados["bim2"],dados["v"]);

