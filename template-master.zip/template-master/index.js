console.log('i');

function a() {
  console.log('aaa');
  const my_value = 'a';
  if (x === 20) {
    console.log('bigger');
    if (x > 2) {
      console.log('bigger');
      if (x > 2) {
        console.log('bigger'); console.log('bigger');
        if (x > 2) {
          console.log('bigger'); console.log('bigger');
        }
      }
    }
  }
  console.log('qwerty');
  console.log('qwerty');
  console.log('qwerty');
  console.log('qwerty');
  console.log('qwerty');
  console.log('qwerty');
  console.log('qwerty');
  console.log('qwerty');
}

a();
