// + - * / % **
const a = 2;
console.log(2 + 2 * 3);
console.log ( 2 ** 8 ); // 2*8
console.log( 2 ** (1/2)); // 2 = constante literária
console.log(11 % 11);
let b = "bla";
console.log(b.repeat(10));
